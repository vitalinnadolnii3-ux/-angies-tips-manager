# Angie's Tips Manager v2

Versione aggiornata con statistiche per dipendente divise in Cash, Carta e Totale.

Carica `index.html` nella root del repository GitHub e fai Commit changes.
